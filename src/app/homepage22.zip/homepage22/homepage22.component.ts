import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage22',
  templateUrl: './homepage22.component.html',
  styleUrls: ['./homepage22.component.css']
})
export class Homepage22Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
