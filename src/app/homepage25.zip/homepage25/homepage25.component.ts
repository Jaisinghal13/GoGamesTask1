import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage25',
  templateUrl: './homepage25.component.html',
  styleUrls: ['./homepage25.component.css']
})
export class Homepage25Component implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
