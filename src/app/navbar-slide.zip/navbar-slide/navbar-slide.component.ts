import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-navbar-slide',
  templateUrl: './navbar-slide.component.html',
  styleUrls: ['./navbar-slide.component.css']
})
export class NavbarSlideComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
