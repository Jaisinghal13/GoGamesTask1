import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-homepage17',
  templateUrl: './homepage17.component.html',
  styleUrls: ['./homepage17.component.css'],
})
export class Homepage17Component implements OnInit {
  constructor() {}

  ngOnInit(): void {}
}
